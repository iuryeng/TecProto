/*

03/12/2019
Instituto Federal de Educação, Ciências e Tecnologia – PB 
Campus Campina Grande
Curso: Bacharelado em Engenharia de Computação
Alunos: Willian A. Ullmann Klein – Iury Fernandes
Disciplina: Técnicas de Prototipagem
Professores: Moacy Pereira da Silva, Fagner de Araújo Pereira

BIBLIOTECA PARA SHIELD ARDUINO PONTE H

*/

#ifndef Ponte_H_INCLUDED
#define Ponte_H_INCLUDED

#include <Arduino.h>

class Ponte_H{

  public: 
    // construtor
    Ponte_H(int pin7, int pin6, int pin4, int pin5);

    void Acionar(int sentido,int vel);
    void Frenar();
    
    
  private:
    int pino7;
    int pino6;
    int pino4;
    int pino5;
};

#endif
