/*

03/12/2019
Instituto Federal de Educação, Ciências e Tecnologia – PB 
Campus Campina Grande
Curso: Bacharelado em Engenharia de Computação
Alunos: Willian A. Ullmann Klein – Iury Fernandes
Disciplina: Técnicas de Prototipagem
Professores: Moacy Pereira da Silva, Fagner de Araújo Pereira

BIBLIOTECA PARA SHIELD ARDUINO PONTE H

*/

#include <Ponte_H.h>

Ponte_H::Ponte_H(int pin7, int pin6, int pin4, int pin5){

  this -> pino7 = pin7;
  this -> pino6 = pin6;
  this -> pino4 = pin4;
  this -> pino5 = pin5;

  pinMode(pino7, OUTPUT);
  pinMode(pino6, OUTPUT);
  pinMode(pino4, OUTPUT);
  pinMode(pino5, OUTPUT);
};

void Ponte_H::Acionar(int sentido, int vel){

  if(sentido == 1){ 

        digitalWrite(pino6,LOW);
        digitalWrite(pino5, LOW);

        delay(1);

        analogWrite(pino7,vel);
        digitalWrite(pino4, HIGH);

   } else if(sentido == 2){
        digitalWrite(pino7,LOW);
        digitalWrite(pino4,LOW);

        delay(1);

        analogWrite(pino6,vel);
        digitalWrite(pino5,HIGH);
   }
};

void Ponte_H::Frenar(){
        digitalWrite(pino4, LOW);
        digitalWrite(pino5, LOW);
    
        delay(1);

        digitalWrite(pino7,HIGH);
        digitalWrite(pino6,HIGH);
};
